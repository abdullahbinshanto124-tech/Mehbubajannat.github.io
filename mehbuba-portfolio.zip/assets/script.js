
const navToggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.site-nav');
if(navToggle){
  navToggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}
document.getElementById('year') && (document.getElementById('year').textContent = new Date().getFullYear());
