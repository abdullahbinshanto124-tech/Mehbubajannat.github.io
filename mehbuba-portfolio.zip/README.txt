
Mehbuba Jannat – Portfolio Template (Multi‑Page)
=================================================

How to use
----------
1) Replace placeholder images in /assets/images/ with your own.
   Suggested filenames (keep the same names to avoid editing HTML):
     - profile-main.jpg
     - about-photo.jpg
     - gallery-1.jpg ... gallery-6.jpg
     - jsc-certificate.jpg, jsc-school.jpg
     - ssc-certificate.jpg, ssc-school.jpg
     - hsc-certificate.jpg, hsc-college.jpg
     - university.jpg
     - activity-1.jpg ... activity-9.jpg

2) To change colors or fonts, edit /assets/style.css (variables at the top).

3) Video resume (resume.html) uses Google Drive preview. Replace the file ID in the iframe
   if you change the video: https://drive.google.com/file/<ID>/preview

4) Hosting options:
   - Netlify / Vercel / GitHub Pages: upload this folder or connect your repo.
   - Local: open index.html in your browser.
   - Google Sites: you cannot import this directly, but you can reproduce the layout and copy the content.

5) Contact form is a demo. Hook up to a service like Formspree if needed.

Enjoy!
